1) First make sure you have installed the following:
	- MySQL server
	- Java IDE
2) Add the JARs from the folder named "UsedJARs" to your IDE
3) Run the project on your IDE